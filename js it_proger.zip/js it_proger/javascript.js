 // Comment in js
    /*
    Comments in few lines
    */
   //document.write("JavaScript said Hello!");
   //console.log("Javascript said Hello!");//выводить на консоль лог
   //console.info("JavaScript, hello!"); 
   //console.error("Javascript said Hello!");//выводить на консоль ошибку
   //console.warn("Javascript said Hello!");//выводить на консоль уведомление/предупреждение

   //const = 5;
   //var num1 = 5;
  // num1 = 8;
  // console.log("Variable: " + num1);

   //var num2 = 5;//intager
   //var num3 = "5";//symbol
   //var num4 = "Words"; //string
   //var number = true; //boolean
  
  /* var num1 = 5;
   var num2 = 15;
   var res = num2 - num1;
   console.log("Вычитание: " + res);
   console.log("Сложение: " + (num1 + num2));

   var num_1 = 5;
   //num_1 = num_1 + 7;
   num_1 += 7;
   console.log("result: " + num_1);

   var str_1 = "12fhdfj";
   var str_2 = "2fk";
   console.log("Сложение: " + (str_1 + str_2));

   console.log("Math: " + Math.PI);
   console.log("Math: " + Math.E);
   console.log("Math: " + Math.min(4, 5, 6, 1, 8, 9, -2));
   console.log("Math: " + Math.max(4, 5, 6, 1, 8, 9, -2));

   var numm = 15;
   var ishousetrue = true;
   if( numm < 5 || ishousetrue){  //условный оператор (|| или)
    console.log("Just say Im Ok");
   } else if(numm != 6) {
      console.log("It's good!")
   }
   else {
      console.log("else");
   }

   var stroka = "word";
   switch(stroka) {
      case "5": 
         console.log("variable with value 5");
         break;
      case "word": 
         console.log("variable with value word");
         break;
      default:
         console.log("default");
   }

   //var arr = new Array();
   var arr = [5, 7, "word", true, 90];
   console.log(arr[1]); //show element with index value 1. 
   console.log(arr.length);

   var matrix = [
      [2, 4 , 6], ["word", 5, 7], [10, 100, 1000]
   ];
   matrix[1][0] = 90;
   console.log(matrix);

   // цикл for
   for(var i = 0; i <= 10; i++){
      console.log(i);
   }
   for(var i = 100; i > 5; i /= 2){
      console.log(i);
   }

   // цикл while 
   var j = 0;
   while(j < 10){
      
      console.log(j);
      j++;
   }
// do while..
   x = 0;
   do {
      console.log(x);
      x++;
   } while(x < 10);


   for(var a = 0; a < 20; a +=2){
      if(a > 15)
         break;
      console.log(a);
   }

   for(var b = 0; b < 20; b++){
      if(b % 2 == 0)
         continue;
      console.log(b);
   } */

   /*var arr = [5, 7, 10, 90, 100, 90];
   for(var i = 0; i < arr.length; i++){
      arr[i] *= 2;
      console.log("Element " + i + ": " + arr[i]);
   }*/

   //alert("Good day today!"); // всплывающее окно
   //confirm("Good day today!"); //  окно с кнопками отмена и ok

   /*var data = confirm("Good day today!"); //  окно с кнопками отмена и ok
console.log(data);*/

  /* var data = confirm("Aru you singl?");
   if(data){
      alert("Good job!");
   }*/

   /*var data = prompt("How ald are you?");
   console.log(data);*/

   /*var person = null;
   if(confirm("Are u sure?")){
      person = prompt("Enter your name");
      alert("Hello, " + person);
   } else{
      alert("You click on Отмена");
   }*/

  /* function info(word) {
      console.log(word + "!");
   }


   function summa(a, b) {
      var res = a + b;
      info(res);
   }

   summa(7, 5);*/

   /*var counter = 0;

   function onClickButton(el) {
      counter++;
      el.innerHTML = "You clicked it!" + counter;
      el.style.background = "green";
      el.style.color = "#333";

      console.log(el.name);
   }

   function onInput(el) {
      if(el.value == "Hello")
         alert("Hello you too!");
      console.log(el.value);
   } */


  /* var text = document.getElementById('text');
   text.title = "New text";
   console.log(text.title);

   text.style.color = "red";
   text.style.backgroundColor = "Blue";
   text.innerHTML = "New<br>Text";

   document.getElementById('text').style.color = "white";


  // var spans = document.getElementsByTagName('span');

  var spans = document.getElementsByClassName('simple-text');
   for(var i = 0; i < spans.length; i++) {
      console.log(spans[i].innerHTML);
   } */

   /*document.getElementById('main-form').addEventListener("submit", checkForm);

   function checkForm(event) {
      event.preventDefault;
      var el = document.getElementById('main-form');

      //var name = document.getElementById('name').value; 
      var name = el.name.value;
      var pass = el.pass.value;
      var state = el.state.value;

      console.log("Name: " + name);
      console.log("Password: " + pass);
      console.log("Gender: " + state);
      console.log("text");
      alert("Ok");
   
      return false;
   } */

   // var id = setInterval(my_func, 1000);

   // var counter = 0;

   // function my_func() {
   //   counter++;
   //   console.log("Counter: " + counter);

   //   if(counter == 3) {
   //    clearInterval(id);
   //   }
   // }

   // // setInterval(function(){
   // //    counter++;
   // //    console.log("Second: " + counter);
   // // }, 1500);

   // setTimeout(function(){
   //    console.log("Timer is working!");
   // }, 2000);

   // var date = new Date();

   // // date.setHours("00");
   // // date.setMinutes("00");

   // console.log(date.getFullYear());
   // console.log(date.getMonth());
   // console.log(date.getDay());
   // console.log(date.getDay());
   // console.log("Time: " + date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds());


   //  var arr = [90, 5, -7, 8, 9];
   //  var stroka = arr.reverse().join(", ");
   // // console.log(arr.join("*"));
   // // console.log(arr.sort());
   // console.log(stroka.split(", "));


   class Person {
      constructor(name, age, happiness) {
         this.name = name;
         this.age = age;
         this.happiness = happiness;

      }
   }

   var alex = new Person('Alex', 20, true);
   var bob = new Person('Bobby', 10, true);
   console.log(alex.name);
   console.log(bob.name);